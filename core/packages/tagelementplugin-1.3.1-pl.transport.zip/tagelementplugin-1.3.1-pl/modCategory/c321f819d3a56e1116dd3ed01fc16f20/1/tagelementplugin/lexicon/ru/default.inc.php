<?php
$_lang['save_as'] = 'Сохранить как';
$_lang['copy_of'] = 'Копия';
$_lang['tagelementplugin_tag_value'] = 'Значение тега';
$_lang['tagelementplugin_err_nf'] = 'Тег не найден!';
// Errors
$_lang['chunk_err_nf'] = 'Чанк не найден! Создать новый чанк?';
$_lang['snippet_err_nf'] = 'Сниппет не найден! Создать новый сниппет?';
$_lang['file_err_nf'] = 'Файл с таким именем не найден!';
$_lang['chunk_err_ae'] = 'Чанк с таким именем уже существует!';
$_lang['snippet_err_ae'] = 'Сниппет с таким именем уже существует!';

